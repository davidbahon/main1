jlog("Hello World")
