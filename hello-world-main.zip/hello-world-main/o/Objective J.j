document.write("Hello World");
