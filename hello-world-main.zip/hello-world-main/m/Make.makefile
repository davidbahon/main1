$(info "Hello World")
all:
