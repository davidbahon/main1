print 'Hello World'
