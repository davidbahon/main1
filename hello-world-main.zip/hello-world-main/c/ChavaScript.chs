בקרה.תעד("Hello World")
