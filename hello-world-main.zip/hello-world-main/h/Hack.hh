<?hh 
echo "Hello World";
