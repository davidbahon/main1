print "Hello World"

