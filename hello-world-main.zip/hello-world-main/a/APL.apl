⎕←'Hello World'

