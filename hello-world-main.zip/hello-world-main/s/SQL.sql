SELECT 'Hello World';
