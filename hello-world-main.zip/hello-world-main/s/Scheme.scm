(display "Hello World") (newline)
